#include <stdio.h>

#include <stdlib.h>

#include <allegro.h>

void initAllegro();

int main()

{

    initAllegro();

    BITMAP *image1;

    BITMAP *buffer1;


    image1=load_bitmap("fond.bmp",NULL);

    show_mouse(screen);

    buffer1=create_bitmap(SCREEN_W,SCREEN_H);


  //t�l�chargement des polices
    FONT *police = NULL; /// Initialisation Polices
    police = load_font("police.pcx",NULL,NULL);
    if(!police)
        allegro_message("Erreur chargement police");
    if(image1==NULL)

        printf("PBm load bitmap");

    while ( !key[KEY_ESC] )

    {


        blit(image1,buffer1,0,0,0,0,SCREEN_W,SCREEN_H) ;
        textout_ex(buffer1, police, "RETOUR",370, SCREEN_H-140, makecol(255, 255, 255), -1);
        textout_ex(buffer1, police, "AU",380, SCREEN_H-117, makecol(255, 255, 255), -1);
        textout_ex(buffer1, police, "MENU",370, SCREEN_H-94, makecol(255, 255, 255), -1);

         if(mouse_x>=351 && mouse_x <=456 && mouse_y >= 449 && mouse_y <= 520 )          //Si on passe la souris sur la touche elle change de couleur
        {
           textout_ex(buffer1, police, "RETOUR",370, SCREEN_H-140, makecol(90, 100, 49), -1);
           textout_ex(buffer1, police, "AU",380, SCREEN_H-117, makecol(90, 100, 49), -1);
           textout_ex(buffer1, police, "MENU",370, SCREEN_H-94, makecol(90, 100, 49), -1);
        }
             if(mouse_b & 1 && mouse_x>=351 && mouse_x <=456 && mouse_y >= 449 && mouse_y <= 520 ) //on clique
        {
               allegro_message("Nous allons vous rediriger vers le menu");
        }

        textout_ex(buffer1, police, "REJOUER",85, SCREEN_H-140, makecol(255, 255, 255), -1);
        textout_ex(buffer1, police, "LA MEME",85, SCREEN_H-117, makecol(255, 255, 255), -1);
        textout_ex(buffer1, police, "PARTIE",85, SCREEN_H-94, makecol(255, 255, 255), -1);

        if(mouse_x>=80 && mouse_x <=184 && mouse_y >= 449 && mouse_y <= 520 )
        {
        textout_ex(buffer1, police, "REJOUER",85, SCREEN_H-140, makecol(90, 100, 49), -1);
        textout_ex(buffer1, police, "LA MEME",85, SCREEN_H-117, makecol(90, 100, 49), -1);
        textout_ex(buffer1, police, "PARTIE",85, SCREEN_H-94, makecol(90, 100, 49), -1);
        }
         if(mouse_b & 1 && mouse_x>=80 && mouse_x <=184 && mouse_y >= 449 && mouse_y <= 520 )
         {
             allegro_message("Bonne chance !");

         }

        textout_ex(buffer1, police, "QUITTER",615, SCREEN_H-117, makecol(255, 255, 255), -1);
        if(mouse_x>=613 && mouse_x <=714 && mouse_y >= 449 && mouse_y <= 520 )
        {
             textout_ex(buffer1, police, "QUITTER",615, SCREEN_H-117, makecol(90,100,49), -1);
        }
         if(mouse_b & 1 && mouse_x>=613 && mouse_x <=714 && mouse_y >= 449 && mouse_y <= 520 )
         {
             allegro_message("A bientot !");
             return 0;
         }



        blit(buffer1,screen,0,0,0,0,SCREEN_W,SCREEN_H);




    }

    destroy_bitmap(image1);



    return-1;



} END_OF_MAIN() ;



void initAllegro()

{

    allegro_init();

    install_mouse();

    install_keyboard();

    set_color_depth(desktop_color_depth());

    if((set_gfx_mode(GFX_AUTODETECT_WINDOWED,800,600,0,0))!=0)

    {

        allegro_message("Pb de mode graphique") ;

        allegro_exit();

        exit(EXIT_FAILURE);

    }

}

